<?php
// Text
$_['text_title']       = 'Frete Especial';
$_['text_description'] = 'Custo do frete para entrega regional.';
?>