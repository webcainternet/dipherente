<?php
/**
 * @version		$Id: NAME.xxx 2014-6-5 10:44Z mic $
 * @package		Language Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['entry_tax_class']	= 'Steuerklasse';
$_['entry_geo_zone']	= 'Geozone';
$_['entry_status']		= 'Status';
$_['entry_sort_order']	= 'Reihenfolge';