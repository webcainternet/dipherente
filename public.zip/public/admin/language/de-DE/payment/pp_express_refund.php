<?php
/**
 * @version		$Id: pp_express_refund.php 3750 2014-09-28 16:22:31Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']				= 'Rückerstattung Transaktion';

$_['text_pp_express']			= 'PayPal Express Checkout';
$_['text_current_refunds']		= 'Für diese Transaktion wurden bereits Rückerstattungen geleistet. Maximaler Betrag ist';

$_['entry_transaction_id']		= 'Transaktionsnr.';
$_['entry_full_refund']			= 'Vollständige Rückerstattung';
$_['entry_amount']				= 'Betrag';
$_['entry_message']				= 'Nachricht';

$_['button_refund']				= 'Rückerstattung';

$_['error_partial_amt']			= 'Es muss mindestens ein Teilbetrag rückerstattet werden';
$_['error_data']				= 'Daten aus Anforderung fehlen';